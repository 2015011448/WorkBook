package com.mingrisoft.dcb1;

import java.util.ArrayList;
import java.util.HashMap;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    // 控件
    private Button addBtn;
    private Button deleteBtn;
    private Button editBtn;
    private Button queryBtn;
    private Button help;
    private ListView listview;
    private ImageView imageView;
    // 数组
    private SimpleAdapter listItemAdapter;
    private ArrayList listItem = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 获取控件
        addBtn = (Button) findViewById(R.id.add_id);
        deleteBtn = (Button) findViewById(R.id.delete_id);
        editBtn = (Button) findViewById(R.id.edit_id);
        queryBtn = (Button) findViewById(R.id.query_id);
        listview = (ListView) findViewById(R.id.show_result);
        help=(Button)findViewById(R.id.help);
        imageView=(ImageView)findViewById(R.id.image) ;
        // 初始化数据
        init();
        // 设置控件事件监听
        addBtn.setOnClickListener(addClick);
        deleteBtn.setOnClickListener(deleteClick);
        editBtn.setOnClickListener(editClick);
        queryBtn.setOnClickListener(queryClick);
        help.setOnClickListener(helper);
    }

    //帮助
    OnClickListener helper=new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 加载输入框的布局文件
            LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.help, null);
            //弹框
            /* setTitle()弹出窗口的最上头文字 */
            /* setIcon设置弹出窗口的图式 */
            /* setMessage设置弹出窗口的信息 */
            new AlertDialog.Builder(MainActivity.this).setTitle("帮助").setIcon(android.R.drawable.ic_dialog_info).setMessage("").setView(layout)
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialoginterface, int i) {
                                    TextView inputStringr = (TextView) layout.findViewById(R.id.help);
                                    String str = inputStringr.getText().toString();
                                    Toast.makeText(getApplicationContext(), "确认", Toast.LENGTH_SHORT).show();
                                }
                            }).setNegativeButton("取消", new DialogInterface.OnClickListener() { /* 设置跳出窗口的返回事件 */
                                public void onClick(DialogInterface dialoginterface, int i) {
                                    Toast.makeText(MainActivity.this,"取消", Toast.LENGTH_SHORT).show();
                                }
                            }).show();
        }
    };
    // 添加事件响应
    OnClickListener addClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 加载输入框的布局文件
            LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.input_add, null);
            // 弹出的对话框
            new AlertDialog.Builder(MainActivity.this).setTitle("添加单词").setIcon(android.R.drawable.ic_dialog_info).setMessage("请输入添加的单词")
                    .setView(layout).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialoginterface, int i) {
                                    EditText inputStringr = (EditText) layout.findViewById(R.id.input_add_string);
                                    String str = inputStringr.getText().toString();
                                    if (str == null || str.equals("")) {
                                        Toast.makeText(getApplicationContext(), "添加的内容不能为空", Toast.LENGTH_SHORT).show();
                                    }
                                    else {
                                        HashMap map = new HashMap();
                                        map.put("viewspot", str);
                                        listItem.add(0, map);
                                        // 如果在前面添加一条数据添加
                                        // listItem.add(map);
                                        listItemAdapter.notifyDataSetChanged();
                                        Toast.makeText(MainActivity.this, "添加的单词为:" + str + "", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }).setNegativeButton("取消", new DialogInterface.OnClickListener() { /* 设置跳出窗口的返回事件 */
                                public void onClick(DialogInterface dialoginterface, int i) {Toast.makeText(MainActivity.this,
                                        "单词添加失败", Toast.LENGTH_SHORT).show();
                                }
                            }).show();
        }
    };
    // 删除事件响应
    OnClickListener deleteClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 加载输入框的布局文件
            LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.input_delete, null);
            // 弹出的对话框
            new AlertDialog.Builder(MainActivity.this).setTitle("删除单词").setIcon(android.R.drawable.ic_dialog_info).setMessage("请输入删除的单词索引")
                    .setView(layout).setPositiveButton("确定",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialoginterface, int i) {
                                    EditText inputNumber = (EditText) layout.findViewById(R.id.input_delete_number);
                                    String str = inputNumber.getText().toString();
                                    if (str == null || str.equals("")) {
                                        Toast.makeText(getApplicationContext(), "请输入一个数字", Toast.LENGTH_SHORT).show();
                                    }
                                    else {
                                        int number = Integer.valueOf(str);
                                        int size = listItem.size();
                                        // 判断数字是否超出数组索引范围
                                        if (number >= size) {
                                            Toast.makeText(getApplicationContext(), "没有找到删除的单词索引", Toast.LENGTH_SHORT).show();
                                        } else {
                                            String value = listItem.get(number).toString();
                                            listItem.remove(number);
                                            listItemAdapter.notifyDataSetChanged();
                                            Toast.makeText(MainActivity.this, "删除的单词为:" + value + "", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            }).setNegativeButton("取消", new DialogInterface.OnClickListener() { /* 设置跳出窗口的返回事件 */
                                public void onClick(DialogInterface dialoginterface, int i) {Toast.makeText(MainActivity.this,
                                            "取消了删除单词", Toast.LENGTH_SHORT).show();
                                }
                            }).show();
        }
    };
    // 修改事件响应
    OnClickListener editClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 加载输入框的布局文件
            LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.input_edit, null);
            // 弹出的对话框
            new AlertDialog.Builder(MainActivity.this).setTitle("修改单词").setIcon(android.R.drawable.ic_dialog_info)
                    .setMessage("请输入修改的索引及内容").setView(layout).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialoginterface, int i) {
                                    EditText inputEditNumber = (EditText) layout.findViewById(R.id.input_edit_number);
                                    String numberStr = inputEditNumber.getText().toString();
                                    EditText inputEditString = (EditText) layout.findViewById(R.id.input_edit_string);
                                    String editStr = inputEditString.getText().toString();
                                    if (numberStr == null || numberStr.equals("")) {
                                        Toast.makeText(getApplicationContext(), "请输入要修改的索引", Toast.LENGTH_SHORT).show();
                                    }
                                    else {
                                        int number = Integer.valueOf(numberStr);
                                        int size = listItem.size();
                                        // 判断数字是否超出数组索引范围
                                        if (number >= size) {
                                            Toast.makeText(
                                                    getApplicationContext(), "没有找到修改的单词索引", Toast.LENGTH_SHORT).show();
                                        }
                                        else {
                                            HashMap map = new HashMap();
                                            map.put("viewspot", editStr);
                                            listItem.set(number, map);
                                            listItemAdapter.notifyDataSetChanged();
                                            Toast.makeText(MainActivity.this, "单词修改为:" + editStr + "", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() { /* 设置跳出窗口的返回事件 */
                                public void onClick(DialogInterface dialoginterface, int i) {Toast.makeText(MainActivity.this,
                                        "取消了修改单词", Toast.LENGTH_SHORT).show();
                                }
                            }).show();
        }
    };
    // 查询事件响应
    OnClickListener queryClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 查询数据
            listItemAdapter.notifyDataSetChanged();
        }
    };
    // 初始化数据
    private void init() {
        listItem = new ArrayList();
            HashMap map = new HashMap();
            map.put("viewspot", "word");
            listItem.add(map);
        listItemAdapter = new SimpleAdapter(getApplicationContext(), listItem,// 数据源
                R.layout.items, new String[] { "viewspot", "add" }, new int[] {
                R.id.viewspot, R.id.add });
        listview.setAdapter(listItemAdapter);

    }
}
